Selamat akun anda telah aktif<br />
Sekarang anda dapat melakukan login<br /><br />

<?php echo anchor('sip_anggota/', 'Masuk Sekarang');?>