<?php
      //echo 'Selamat akun anda berhasil dibuat, anda bisa masuk kesistem '. '<br />';
      //echo anchor('sip_anggota/', 'Masuk Sekarang');
?>


Selamat akun anda berhasil di buat<br />
Silahkan cek email anda ( <i><?php echo $usermail?></i> ) untuk melakukan Aktivasi<br /><br />
<?php echo anchor('', 'Kembali Ke Halaman Depan')?>